﻿using Abp.MultiTenancy;
using JosenBug.Authorization.Users;

namespace JosenBug.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
